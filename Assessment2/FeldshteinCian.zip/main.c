// Created by Cian on 16/04/2018.
// R00142270
#include <stdio.h>
#include <stdlib.h>
#include "game.h"

    int main(int argc, char **argv)
{
    play_game(argv[1], argv[2]);
    return 0;
}
// example of running the code
// a cian john           this will start a game between cian and john
